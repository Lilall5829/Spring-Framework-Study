package com.example.assign2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assign2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
